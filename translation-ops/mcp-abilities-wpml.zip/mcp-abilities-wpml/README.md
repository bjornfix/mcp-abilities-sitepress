# MCP Abilities - WPML

Small bridge plugin that exposes WPML translation mapping as MCP abilities.

## Abilities

- `wpml/list-page-translation-status`
- `wpml/ensure-page-translation`
- `wpml/detect-untranslated-content`

## Why this exists

`gmekka.devenia.com` has WPML active, but the existing MCP abilities do not expose
translation linkage (source page -> target page). This plugin adds that missing
control layer so translation can run page-by-page without guessing IDs, and adds
an automatic language-agnostic QA check before publish.

## Notes

- Requires `abilities-api` and WPML (`sitepress-multilingual-cms`) to be active.
- `wpml/ensure-page-translation` can create target translation shells and copy
  Elementor metadata from source pages.
- `wpml/detect-untranslated-content` compares source and target page text and
  flags likely untranslated leftovers (shared terms + exact copied segments).
